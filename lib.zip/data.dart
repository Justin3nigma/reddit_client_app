class GenData {
  Data data;

  GenData({this.data});

  GenData.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();

    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Data {
  List<Children> children;

  Data({this.children});

  factory Data.fromJson(Map<String, dynamic> json) {
    return Data(
      children: parsechildren(json['children']),
    );
    }

  static List<Children> parsechildren(childrenJson) {
    List<Children> childrenList = new List<Children>.from(childrenJson);
    return childrenList;
  }
}

class Children {
  final Datas data;

  Children({this.data});

  factory Children.fromJson(Map<String, dynamic> parsedJson) {
    return Children(data: parsedJson['data']);
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Datas {
  String authorFullname;
  String title;
  String thumbnail;

  Datas({this.authorFullname, this.title, this.thumbnail});

    factory Datas.fromJson(Map<String, dynamic> json) {
      return Datas(
          authorFullname: json['author_fullname'],
          title: json['title'],
          thumbnail: json['thumbnail']
      );
  }
}